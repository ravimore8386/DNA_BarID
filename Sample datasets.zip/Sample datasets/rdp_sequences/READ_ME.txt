#DNA BarID
#All sequences retrieved from the RDP browser based on combination of following criterion:  
#(Strain: Type, Source: isolates, Size :>=1200; Quality: Good; Taxonomy: RDP nomenclature) for isolate sequences

There are two subsets for each taxon 
I. Taxa: comprised of taxa sequences
	1.Bacilli(class)_1180seqs.fasta
	2.Bacillales(Order)_780seqs.fasta
	3.Bacillaceae(Family)_346seqs.fasta
	4.Bacillus(Genus)_181seqs.fasta

II.Others: comprised of rest of the bacterial sequences 	
	1.Others_class_8014seqs.fasta
	2.Others_order_8414seqs.fasta
	3.Others_family_8848seqs.fasta
	4.Others_genus_9013seqs.fasta
